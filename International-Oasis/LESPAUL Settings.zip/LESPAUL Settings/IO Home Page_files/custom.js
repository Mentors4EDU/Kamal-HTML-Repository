jQuery(document).ready(function($){
	// JS goes here
});
